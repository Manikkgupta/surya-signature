/* Surya Signature - shared script (header, footer, products, filters) */

/* EDIT: WhatsApp number, country code first, digits only */
const WHATSAPP = "91XXXXXXXXXX";

const $ = (s, r = document) => r.querySelector(s);
const inr = n => "₹" + n.toLocaleString("en-IN");
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
const wa = text => "https://wa.me/" + WHATSAPP + (text ? "?text=" + encodeURIComponent(text) : "");

/* ---------- categories ---------- */
const CATS = {
  Men: ["Heavy Embroidered Sherwanis","Kurta Pajamas","Indo-Western","Bandhgala","Open Jodhpuri","Party Wear Waistcoats","Heavy Embroidered Suits","Formal Pants","Party Wear Shirts"],
  Kids: ["Kids Suits","Kids Indo-Western","Kids Formal Suits","Kids Ethnic Wear","Kids Party Wear"]
};

/* ---------- products (EDIT: later replace with data from your database) ----------
   a = Men | Kids, s = sale price (0 = none), st = stock, b = Bestseller,
   nw = New Arrival, ft = Featured, alt = Alteration available */
const U = id => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=700&q=80`;
const PRODUCTS = [
 {n:"Ivory Heritage Sherwani",sku:"M-SH-001",a:"Men",c:"Heavy Embroidered Sherwanis",p:18990,s:0,st:5,sz:["M","L","XL"],co:["Ivory","Gold"],f:"Silk",o:"Wedding",b:1,nw:0,ft:1,alt:1,i:"1594938298603-c8148c4dae35"},
 {n:"Midnight Bandhgala",sku:"M-BG-002",a:"Men",c:"Bandhgala",p:12990,s:10990,st:8,sz:["S","M","L"],co:["Black","Navy"],f:"Velvet",o:"Party",b:1,nw:1,ft:0,alt:1,i:"1507679799987-c73779587ccf"},
 {n:"Classic Celebration Suit",sku:"M-ST-003",a:"Men",c:"Heavy Embroidered Suits",p:16990,s:0,st:0,sz:["L","XL"],co:["Grey","Black"],f:"Wool Blend",o:"Wedding",b:1,nw:0,ft:0,alt:1,i:"1598033129183-c4f50c736f10"},
 {n:"Contemporary Indo-Western",sku:"M-IW-004",a:"Men",c:"Indo-Western",p:11990,s:0,st:6,sz:["M","L"],co:["Champagne","Maroon"],f:"Silk",o:"Reception",b:0,nw:1,ft:1,alt:1,i:"1617137968427-85924c800a22"},
 {n:"Evening Jodhpuri",sku:"M-JD-005",a:"Men",c:"Open Jodhpuri",p:14990,s:0,st:4,sz:["M","L","XL"],co:["Navy","Black"],f:"Velvet",o:"Party",b:0,nw:1,ft:0,alt:1,i:"1594938298603-c8148c4dae35"},
 {n:"Ivory Kurta Pajama",sku:"M-KP-006",a:"Men",c:"Kurta Pajamas",p:5990,s:0,st:12,sz:["S","M","L","XL"],co:["Ivory"],f:"Cotton",o:"Festive",b:0,nw:0,ft:0,alt:0,i:"1507679799987-c73779587ccf"},
 {n:"Little Gentleman Suit",sku:"K-ST-001",a:"Kids",c:"Kids Suits",p:4990,s:0,st:7,sz:["4-5Y","6-7Y","8-9Y"],ag:["4-7","8-12"],co:["Navy","Beige"],o:"Party",b:1,nw:0,ft:1,alt:1,i:"1519238263530-99bdd11df2ea"},
 {n:"Little Heritage Indo-Western",sku:"K-IW-002",a:"Kids",c:"Kids Indo-Western",p:5490,s:4990,st:5,sz:["2-3Y","4-5Y","6-7Y"],ag:["1-3","4-7"],co:["Beige","Maroon"],o:"Festive",b:0,nw:1,ft:0,alt:1,i:"1519238263530-99bdd11df2ea"}
];

/* ---------- shared header + footer (identical on every page) ---------- */
const NAV = [["Home","index.html"],["Men","men.html"],["Kids","kids.html"],["Appointment","contact.html#appointment"],["About Us","index.html#about"],["Contact Us","contact.html"]];
const page = location.pathname.split("/").pop() || "index.html";

const HEADER = `
<div class="announce">Crafted for your special moments. Complimentary in-store style consultation.</div>
<header class="header">
  <div class="wrap topbar">
    <a href="index.html" class="brand"><span class="mark">S</span>
      <span><span class="bname">SURYA SIGNATURE</span><span class="btag">Where Tradition Meets Signature Style</span></span></a>
    <div class="actions">
      <button class="ic" id="sbtn" type="button">Search</button>
      <button class="ic" data-soon="wish" type="button">Wishlist (<span id="wc">0</span>)</button>
      <button class="ic" data-soon="cart" type="button">Cart (<span id="cc">0</span>)</button>
      <button class="ic" data-soon="acc" type="button">Account</button>
      <button class="ic google" data-soon="acc" type="button">Continue with Google</button>
      <button class="menu-btn" id="mbtn" type="button" aria-label="Menu" aria-expanded="false">☰</button>
    </div>
  </div>
  <form class="searchbar" id="sform" action="men.html"><div class="wrap"><input name="q" id="sq" placeholder="Search products, e.g. sherwani" aria-label="Search products"></div></form>
  <nav class="nav" id="nav" aria-label="Main navigation">
    ${NAV.map(([l,h]) => `<a href="${h}"${h === page ? ' class="active"' : ""}>${l}</a>`).join("")}
  </nav>
</header>`;

const FOOTER = `
<footer class="footer"><div class="wrap">
  <div class="fg">
    <div>
      <div class="brand"><span class="mark" style="width:36px;height:36px;font-size:24px">S</span>
        <span><span class="bname" style="font-size:21px">SURYA SIGNATURE</span><span class="btag" style="color:#b9bda6">Where Tradition Meets Signature Style</span></span></div>
      <p class="fl">Considered style for life's defining moments. Premium ethnic, western and occasion wear for men and kids.</p>
    </div>
    <div><h4>Quick links</h4><div class="fl">
      <a href="men.html">Men's Collection</a><a href="kids.html">Kids' Collection</a>
      <a href="contact.html#appointment">Book an Appointment</a><a href="index.html#about">About Us</a><a href="contact.html">Contact Us</a></div></div>
    <div><h4>Store locator</h4><div class="fl">
      <a href="contact.html#stores">Surya Signature — Main Store</a>
      <a href="contact.html#stores">Surya Fashion World — Branch of Surya Signature</a></div></div>
    <div><h4>Newsletter</h4>
      <form id="nform"><input type="email" placeholder="Your email address" aria-label="Your email address" required><button type="submit">Join</button></form></div>
  </div>
  <div class="fb"><span>© 2026 Surya Signature. All rights reserved.</span><span>Where Tradition Meets Signature Style</span></div>
</div></footer>
<a class="wa" href="${wa()}" aria-label="Chat on WhatsApp">WhatsApp</a>
<dialog id="qv"></dialog><div class="toast" id="toast" role="status"></div>`;

document.body.insertAdjacentHTML("afterbegin", HEADER);
document.body.insertAdjacentHTML("beforeend", FOOTER);

/* ---------- header behaviour ---------- */
let cart = store.get("cart", []), wish = store.get("wish", []);
function counts() { $("#cc").textContent = cart.length; $("#wc").textContent = wish.length; }
counts();
function toast(m) { const t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 2600); }

$("#mbtn").onclick = e => { const o = $("#nav").classList.toggle("open"); e.currentTarget.setAttribute("aria-expanded", o); };
if (page === "kids.html") $("#sform").action = "kids.html";
$("#sbtn").onclick = () => { $("#sform").classList.toggle("open"); $("#sq").focus(); };
$("#nform").onsubmit = e => { e.preventDefault(); e.target.reset(); toast("Thank you for joining."); };
document.addEventListener("click", e => {
  const s = e.target.closest("[data-soon]");
  if (s) toast(s.dataset.soon === "cart" ? `Your cart has ${cart.length} item(s). Checkout opens once the store backend is connected.`
    : s.dataset.soon === "wish" ? `You have ${wish.length} saved item(s).` : "Login opens once the store backend is connected.");
});

/* ---------- product cards, quick view ---------- */
function card(x) {
  const price = x.s ? `<s>${inr(x.p)}</s><b>${inr(x.s)}</b>` : inr(x.p);
  const tag = x.s ? "Sale" : x.nw ? "New" : x.b ? "Bestseller" : x.ft ? "Featured" : "";
  const out = x.st <= 0;
  return `<article class="pcard"><div class="pimg"><img loading="lazy" src="${U(x.i)}" alt="${x.n}">
    ${tag ? `<span class="badge">${tag}</span>` : ""}${out ? `<span class="badge out">Out of stock</span>` : ""}
    <button class="heart${wish.includes(x.sku) ? " on" : ""}" data-wish="${x.sku}" type="button" aria-label="Save to wishlist">${wish.includes(x.sku) ? "♥" : "♡"}</button></div>
    <div class="pinfo"><div class="pcat">${x.c}</div><div class="pname">${x.n}</div><div class="price">${price}</div>
    <div class="pbtn"><button class="btn ghost" data-qv="${x.sku}" type="button">Quick View</button>
    <button class="btn" data-add="${x.sku}" type="button"${out ? " disabled" : ""}>Add to Cart</button></div></div></article>`;
}

document.addEventListener("click", e => {
  const h = e.target.closest("[data-wish]"), a = e.target.closest("[data-add]"), q = e.target.closest("[data-qv]");
  if (h) {
    const s = h.dataset.wish; wish = wish.includes(s) ? wish.filter(v => v !== s) : [...wish, s]; store.set("wish", wish);
    document.querySelectorAll(`[data-wish="${s}"]`).forEach(b => { const on = wish.includes(s); b.classList.toggle("on", on); b.textContent = on ? "♥" : "♡"; });
    counts();
  }
  if (a) { cart.push(a.dataset.add); store.set("cart", cart); counts(); toast("Added to cart."); }
  if (q) {
    const x = PRODUCTS.find(p => p.sku === q.dataset.qv), d = $("#qv");
    d.innerHTML = `<div class="qv"><img src="${U(x.i)}" alt="${x.n}"><div class="qv-c">
      <button class="qx" type="button" data-close aria-label="Close">×</button>
      <div class="pcat">${x.c}</div><h3 style="font-size:30px">${x.n}</h3>
      <div class="price">${x.s ? `<s>${inr(x.p)}</s><b>${inr(x.s)}</b>` : inr(x.p)}</div>
      <p class="muted" style="font-size:14px">Colors: ${x.co.join(", ")}${x.f ? " · Fabric: " + x.f : ""} · ${x.o}${x.alt ? " · Alteration available" : ""}</p>
      <select aria-label="Size">${x.sz.map(z => `<option>${z}</option>`).join("")}</select>
      <button class="btn" data-add="${x.sku}" type="button"${x.st <= 0 ? " disabled" : ""}>Add to Cart</button>
      <a class="link" href="${wa("Hi, I am interested in " + x.n + " (" + x.sku + ")")}" style="justify-self:start">Ask on WhatsApp</a></div></div>`;
    d.showModal();
  }
  if (e.target.closest("[data-close]") || e.target === $("#qv")) $("#qv").close();
});

/* ---------- catalog page (men.html / kids.html) ---------- */
function catalog(aud) {
  const items = PRODUCTS.filter(x => x.a === aud);
  const F = aud === "Men"
    ? [["Category","c"],["Size","sz"],["Color","co"],["Occasion","o"],["Fabric","f"]]
    : [["Category","c"],["Age","ag"],["Size","sz"],["Color","co"],["Occasion","o"]];
  const BANDS = [["Under ₹5,000",0,4999],["₹5,000 – ₹10,000",5000,10000],["₹10,000 – ₹15,000",10001,15000],["Above ₹15,000",15001,1e9]];
  const P = new URLSearchParams(location.search);
  const st = { q: (P.get("q") || "").toLowerCase(), sel: { c: P.get("cat") || "", o: P.get("occ") || "" }, price: "", stock: false };
  if (st.q) $("#sq").value = P.get("q");
  const val = (x, k) => [].concat(x[k] || []);

  $("#filters").innerHTML = `<h3>Filter</h3>` + F.map(([l, k]) => {
    const opts = k === "c" ? CATS[aud] : [...new Set(items.flatMap(x => val(x, k)))];
    return `<label>${l}<select data-k="${k}"><option value="">All</option>${opts.map(o => `<option${st.sel[k] === o ? " selected" : ""}>${o}</option>`).join("")}</select></label>`;
  }).join("") +
  `<label>Price<select data-k="price"><option value="">All</option>${BANDS.map((b, i) => `<option value="${i}">${b[0]}</option>`).join("")}</select></label>
   <label class="chk full"><input type="checkbox" data-k="stock"> In stock only</label>
   <button class="btn ghost full" type="button" id="clr">Clear filters</button>`;

  function apply() {
    const list = items.filter(x => {
      if (st.q && !(x.n + " " + x.c + " " + x.o).toLowerCase().includes(st.q)) return false;
      for (const k in st.sel) if (st.sel[k] && !val(x, k).includes(st.sel[k])) return false;
      if (st.price !== "") { const b = BANDS[st.price], pr = x.s || x.p; if (pr < b[1] || pr > b[2]) return false; }
      if (st.stock && x.st <= 0) return false;
      return true;
    });
    $("#count").textContent = list.length + " product" + (list.length === 1 ? "" : "s");
    $("#grid").innerHTML = list.length ? list.map(card).join("") : `<p class="empty">No products match these filters. Try clearing a filter.</p>`;
  }
  $("#filters").addEventListener("change", e => {
    const k = e.target.dataset.k; if (!k) return;
    if (k === "price") st.price = e.target.value; else if (k === "stock") st.stock = e.target.checked; else st.sel[k] = e.target.value;
    apply();
  });
  $("#clr").onclick = () => { st.q = ""; st.sel = {}; st.price = ""; st.stock = false; $("#sq").value = ""; $("#filters").querySelectorAll("select").forEach(s => s.value = ""); $("#filters input").checked = false; apply(); };
  apply();
}
